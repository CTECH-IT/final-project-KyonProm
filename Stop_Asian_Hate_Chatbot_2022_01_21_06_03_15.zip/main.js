function setup() {
  createCanvas(windowWidth, windowHeight);
 background(250, 0, 100);
}
